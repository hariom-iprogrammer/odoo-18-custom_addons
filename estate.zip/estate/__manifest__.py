{
    'name': "Real Estate",
    'version': '1.0',
    'depends': ['base'],
    'author': 'Your Name',
    'category': 'Real Estate',
    'description': "Manage properties for sale or rent",
    'data': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
